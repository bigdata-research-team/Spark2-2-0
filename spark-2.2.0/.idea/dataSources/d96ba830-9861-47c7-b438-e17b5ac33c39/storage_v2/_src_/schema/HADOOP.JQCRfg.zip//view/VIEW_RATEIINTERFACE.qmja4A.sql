create view VIEW_RATEIINTERFACE as
select  fzqlb ,fszsh,ffvlb,flv,fzklv from csjylv  where  fjjdm =0    --- 交易费率等于0的公用数据
/

