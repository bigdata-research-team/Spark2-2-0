create view VIEW_ZHQPZH as
select a."FQSDM",a."FSZSH",a."FSETID",b."ShiCh",b."TouZPZh",b."MingCh",b."BiaoSh",a."FSETCODE" from VIEW_ASSETCODE a inner join (select * from "ZhQPZh") b on b."BiaoSh"=a.FSZSH
/

