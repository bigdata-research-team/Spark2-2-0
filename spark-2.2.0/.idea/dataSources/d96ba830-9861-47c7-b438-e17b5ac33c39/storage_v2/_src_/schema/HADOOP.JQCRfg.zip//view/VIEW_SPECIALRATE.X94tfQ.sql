create view VIEW_SPECIALRATE as
select  fzqlb ,fszsh,ffvlb,flv,fzklv,fjjdm from csjylv  where  fjjdm <>0
/

