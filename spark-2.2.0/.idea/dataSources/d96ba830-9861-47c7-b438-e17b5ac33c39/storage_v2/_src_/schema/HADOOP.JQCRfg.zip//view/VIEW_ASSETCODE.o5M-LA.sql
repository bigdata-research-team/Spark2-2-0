create view VIEW_ASSETCODE as
select a.fqsdm,a.fszsh,b.fsetid ,a.fsetcode  from   csqsxw  a  left join   lsetlist   b  on a.fsetcode=b.fsetcode      ---查询出  席位号、市场、资产代码，套帐号
/

