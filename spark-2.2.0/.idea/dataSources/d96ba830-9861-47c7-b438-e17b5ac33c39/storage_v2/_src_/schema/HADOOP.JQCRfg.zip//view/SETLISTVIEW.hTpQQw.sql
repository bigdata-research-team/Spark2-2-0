create view SETLISTVIEW as
  (select lset.fjjlx,lset.fjjzl,lset.fjjdqdate,lset.fjjcldate,lset.fsetcode,llist.fyear from lsetcssysjj lset left join lsetlist llist on lset.fsetcode = llist.fsetcode)
/

